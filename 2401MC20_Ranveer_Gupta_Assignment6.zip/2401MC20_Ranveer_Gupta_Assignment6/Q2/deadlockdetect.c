//RANVEER GUPTA
//2401MC20
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define MAX_PROC 10
#define MAX_RES 10

// Wait-for graph representation
int wfg[MAX_PROC][MAX_PROC];
int visited[MAX_PROC];
int in_stack[MAX_PROC];
int parent_node[MAX_PROC];
int cycle_start = -1;
int cycle_end = -1;

// Construct wait-for graph from allocation and request matrices
void
build_wfg(int num_p, int num_r, int alloc[MAX_PROC][MAX_RES], int req[MAX_PROC][MAX_RES])
{
  for (int i = 0; i < num_p; i++) {
    for (int j = 0; j < num_p; j++) {
      wfg[i][j] = 0;
    }
  }

  // Edge Pi -> Pj exists if Pi requests resource held by Pj
  for (int i = 0; i < num_p; i++) {
    for (int r = 0; r < num_r; r++) {
      if (req[i][r] > 0) {
        for (int j = 0; j < num_p; j++) {
          if (i != j && alloc[j][r] > 0) {
            wfg[i][j] = 1;
          }
        }
      }
    }
  }

  printf("Wait-For Graph edges:\n");
  int edge_count = 0;
  for (int i = 0; i < num_p; i++) {
    for (int j = 0; j < num_p; j++) {
      if (wfg[i][j]) {
        printf("  P%d -> P%d\n", i, j);
        edge_count++;
      }
    }
  }
  if (edge_count == 0) {
    printf("  (no edges)\n");
  }
}

// DFS cycle detection helper
int
dfs_cycle(int u, int num_p)
{
  visited[u] = 1;
  in_stack[u] = 1;

  for (int v = 0; v < num_p; v++) {
    if (wfg[u][v]) {
      if (!visited[v]) {
        parent_node[v] = u;
        if (dfs_cycle(v, num_p)) {
          return 1;
        }
      } else if (in_stack[v]) {
        cycle_start = v;
        cycle_end = u;
        return 1;
      }
    }
  }

  in_stack[u] = 0;
  return 0;
}

// Detect deadlock using DFS cycle detection
void
detect_deadlock(int num_p)
{
  for (int i = 0; i < num_p; i++) {
    visited[i] = 0;
    in_stack[i] = 0;
    parent_node[i] = -1;
  }
  cycle_start = -1;
  cycle_end = -1;

  int has_cycle = 0;
  for (int i = 0; i < num_p; i++) {
    if (!visited[i]) {
      if (dfs_cycle(i, num_p)) {
        has_cycle = 1;
        break;
      }
    }
  }

  if (has_cycle && cycle_start != -1) {
    printf("Deadlock detected!\n");

    // Reconstruct cycle path
    int cycle_path[MAX_PROC];
    int len = 0;
    cycle_path[len++] = cycle_start;
    for (int curr = cycle_end; curr != cycle_start && curr != -1; curr = parent_node[curr]) {
      cycle_path[len++] = curr;
    }
    cycle_path[len++] = cycle_start;

    printf("Cycle: ");
    for (int i = len - 1; i >= 0; i--) {
      printf("P%d", cycle_path[i]);
      if (i > 0) {
        printf(" -> ");
      }
    }
    printf("\n");
  } else {
    printf("No deadlock detected (graph is acyclic)\n");
  }
}

// Run test scenarios
int
main(void)
{
  // Scenario 1: Acyclic graph (no deadlock)
  printf("Scenario 1 (No Deadlock):\n");
  int alloc1[MAX_PROC][MAX_RES] = {
    {1, 0},
    {0, 1},
    {0, 0}
  };
  int req1[MAX_PROC][MAX_RES] = {
    {0, 0},
    {1, 0},
    {0, 1}
  };
  build_wfg(3, 2, alloc1, req1);
  detect_deadlock(3);

  // Scenario 2: Deadlock with 3-process cycle (P0 -> P1 -> P2 -> P0)
  printf("\nScenario 2 (Circular Wait Deadlock with 3 Processes):\n");
  int alloc2[MAX_PROC][MAX_RES] = {
    {1, 0, 0, 0},
    {0, 1, 0, 0},
    {0, 0, 1, 0},
    {0, 0, 0, 1}
  };
  int req2[MAX_PROC][MAX_RES] = {
    {0, 1, 0, 0},
    {0, 0, 1, 0},
    {1, 0, 0, 0},
    {0, 0, 1, 0}
  };
  build_wfg(4, 4, alloc2, req2);
  detect_deadlock(4);

  exit(0);
}
