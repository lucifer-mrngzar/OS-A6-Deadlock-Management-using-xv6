//RANVEER GUPTA
//2401MC20
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define LOCK1 0
#define LOCK2 1
#define PRINT_LOCK 2

// Thread-safe log print
void
log_step(char *proc_name, char *action)
{
  sem_wait(PRINT_LOCK);
  printf("[%d] %s: %s\n", uptime(), proc_name, action);
  sem_post(PRINT_LOCK);
}

// Run deadlocking scenario (inconsistent resource ordering)
void
run_deadlock_scenario(void)
{
  sem_init(LOCK1, 1);
  sem_init(LOCK2, 1);
  sem_init(PRINT_LOCK, 1);

  printf("Starting deadlock scenario (A: Lock1 -> Lock2, B: Lock2 -> Lock1)\n");

  int pid = fork();
  if (pid < 0) {
    printf("fork failed\n");
    exit(1);
  }

  if (pid == 0) {
    // Process B
    log_step("Process B", "attempting Lock 2");
    sem_wait(LOCK2);
    log_step("Process B", "acquired Lock 2");

    pause(2);

    log_step("Process B", "waiting for Lock 1");
    sem_wait(LOCK1);
    log_step("Process B", "acquired Lock 1");

    sem_post(LOCK1);
    sem_post(LOCK2);
    log_step("Process B", "completed");
    exit(0);
  }

  // Process A
  log_step("Process A", "attempting Lock 1");
  sem_wait(LOCK1);
  log_step("Process A", "acquired Lock 1");

  pause(2);

  log_step("Process A", "waiting for Lock 2");
  sem_wait(LOCK2);
  log_step("Process A", "acquired Lock 2");

  sem_post(LOCK2);
  sem_post(LOCK1);
  log_step("Process A", "completed");

  wait(0);
}

// Run fixed scenario (consistent global resource ordering)
void
run_fixed_scenario(void)
{
  sem_init(LOCK1, 1);
  sem_init(LOCK2, 1);
  sem_init(PRINT_LOCK, 1);

  printf("Starting fixed scenario (Both A and B: Lock1 -> Lock2)\n");

  int pid = fork();
  if (pid < 0) {
    printf("fork failed\n");
    exit(1);
  }

  if (pid == 0) {
    // Process B
    log_step("Process B", "attempting Lock 1");
    sem_wait(LOCK1);
    log_step("Process B", "acquired Lock 1");

    pause(2);

    log_step("Process B", "waiting for Lock 2");
    sem_wait(LOCK2);
    log_step("Process B", "acquired Lock 2");

    pause(1);

    sem_post(LOCK2);
    sem_post(LOCK1);
    log_step("Process B", "completed");
    exit(0);
  }

  // Process A
  log_step("Process A", "attempting Lock 1");
  sem_wait(LOCK1);
  log_step("Process A", "acquired Lock 1");

  pause(2);

  log_step("Process A", "waiting for Lock 2");
  sem_wait(LOCK2);
  log_step("Process A", "acquired Lock 2");

  pause(1);

  sem_post(LOCK2);
  sem_post(LOCK1);
  log_step("Process A", "completed");

  wait(0);
  printf("Fixed scenario completed successfully without deadlock\n");
}

int
main(int argc, char *argv[])
{
  if (argc > 1 && strcmp(argv[1], "bad") == 0) {
    run_deadlock_scenario();
  } else if (argc > 1 && strcmp(argv[1], "fixed") == 0) {
    run_fixed_scenario();
  } else {
    printf("Usage: resourceorder bad | fixed\n");
    printf("Running fixed scenario by default:\n");
    run_fixed_scenario();
  }

  exit(0);
}
