//RANVEER GUPTA
//2401MC20
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define PRINTER 0
#define SCANNER 1
#define DISK 2
#define PRINT_LOCK 3

// Resource labels
char *res_names[3] = {"Printer", "Scanner", "Disk"};

// Process resource requirements (each needs 2 distinct resources)
int proc_res[5][2] = {
  {PRINTER, SCANNER},
  {SCANNER, DISK},
  {PRINTER, DISK},
  {PRINTER, SCANNER},
  {SCANNER, DISK}
};

// Worker process executing multiple cycles
void
worker(int id)
{
  int r1 = proc_res[id][0];
  int r2 = proc_res[id][1];

  // Enforce hierarchical ordering (smaller ID first)
  if (r1 > r2) {
    int tmp = r1;
    r1 = r2;
    r2 = tmp;
  }

  for (int cycle = 1; cycle <= 2; cycle++) {
    // Request and acquire first resource
    sem_wait(PRINT_LOCK);
    printf("[%d] P%d: requesting %s\n", uptime(), id, res_names[r1]);
    sem_post(PRINT_LOCK);

    sem_wait(r1);

    sem_wait(PRINT_LOCK);
    printf("[%d] P%d: granted %s\n", uptime(), id, res_names[r1]);
    sem_post(PRINT_LOCK);

    // Request and acquire second resource
    sem_wait(PRINT_LOCK);
    printf("[%d] P%d: requesting %s\n", uptime(), id, res_names[r2]);
    sem_post(PRINT_LOCK);

    sem_wait(r2);

    sem_wait(PRINT_LOCK);
    printf("[%d] P%d: granted %s\n", uptime(), id, res_names[r2]);
    printf("[%d] P%d: working (cycle %d)\n", uptime(), id, cycle);
    sem_post(PRINT_LOCK);

    // Simulate work
    pause(2);

    // Release resources in reverse order
    sem_post(r2);
    sem_wait(PRINT_LOCK);
    printf("[%d] P%d: released %s\n", uptime(), id, res_names[r2]);
    sem_post(PRINT_LOCK);

    sem_post(r1);
    sem_wait(PRINT_LOCK);
    printf("[%d] P%d: released %s\n", uptime(), id, res_names[r1]);
    sem_post(PRINT_LOCK);

    pause(1);
  }

  exit(0);
}

int
main(void)
{
  // Initialize resource pools: 2 printers, 1 scanner, 2 disks
  sem_init(PRINTER, 2);
  sem_init(SCANNER, 1);
  sem_init(DISK, 2);
  sem_init(PRINT_LOCK, 1);

  printf("Starting multi-resource synchronization with 5 processes\n");

  // Spawn 5 processes
  for (int i = 0; i < 5; i++) {
    int pid = fork();
    if (pid < 0) {
      printf("fork failed\n");
      exit(1);
    }
    if (pid == 0) {
      worker(i);
    }
  }

  // Wait for all 5 processes to finish
  for (int i = 0; i < 5; i++) {
    wait(0);
  }

  printf("All 5 processes completed without deadlock\n");
  exit(0);
}
