//RANVEER GUPTA
//2401MC20
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define P 5
#define R 3

// System state
int alloc[P][R] = {
  {0, 1, 0},
  {2, 0, 0},
  {3, 0, 2},
  {2, 1, 1},
  {0, 0, 2}
};

int max[P][R] = {
  {7, 5, 3},
  {3, 2, 2},
  {9, 0, 2},
  {2, 2, 2},
  {4, 3, 3}
};

int avail[R] = {3, 3, 2};
int need[P][R];

// Calculate need matrix
void
calculate_need(void)
{
  for (int i = 0; i < P; i++) {
    for (int j = 0; j < R; j++) {
      need[i][j] = max[i][j] - alloc[i][j];
    }
  }
}

// Safety algorithm
int
check_safety(int seq[])
{
  int work[R];
  int finish[P];

  for (int i = 0; i < R; i++) {
    work[i] = avail[i];
  }
  for (int i = 0; i < P; i++) {
    finish[i] = 0;
  }

  int count = 0;
  while (count < P) {
    int found = 0;
    for (int p = 0; p < P; p++) {
      if (!finish[p]) {
        int can_allocate = 1;
        for (int j = 0; j < R; j++) {
          if (need[p][j] > work[j]) {
            can_allocate = 0;
            break;
          }
        }
        if (can_allocate) {
          for (int k = 0; k < R; k++) {
            work[k] += alloc[p][k];
          }
          seq[count++] = p;
          finish[p] = 1;
          found = 1;
        }
      }
    }
    if (!found) {
      return 0;
    }
  }
  return 1;
}

// Print safe sequence
void
print_safe_sequence(int seq[])
{
  printf("Safe sequence: ");
  for (int i = 0; i < P; i++) {
    printf("P%d", seq[i]);
    if (i < P - 1) {
      printf(" -> ");
    }
  }
  printf("\n");
}

// Process resource request
int
request_resources(int pid, int req[])
{
  printf("Process P%d requesting [%d, %d, %d]\n", pid, req[0], req[1], req[2]);

  // Check if request exceeds need
  for (int j = 0; j < R; j++) {
    if (req[j] > need[pid][j]) {
      printf("Request denied -- exceeds process maximum claim\n");
      return 0;
    }
  }

  // Check if request exceeds available
  for (int j = 0; j < R; j++) {
    if (req[j] > avail[j]) {
      printf("Request denied -- insufficient resources available\n");
      return 0;
    }
  }

  // Tentative allocation
  for (int j = 0; j < R; j++) {
    avail[j] -= req[j];
    alloc[pid][j] += req[j];
    need[pid][j] -= req[j];
  }

  int seq[P];
  if (check_safety(seq)) {
    printf("Request granted safely\n");
    print_safe_sequence(seq);
    return 1;
  } else {
    // Rollback allocation
    for (int j = 0; j < R; j++) {
      avail[j] += req[j];
      alloc[pid][j] -= req[j];
      need[pid][j] += req[j];
    }
    printf("Request denied -- would lead to unsafe state\n");
    return 0;
  }
}

int
main(int argc, char *argv[])
{
  calculate_need();

  int seq[P];
  if (check_safety(seq)) {
    printf("Initial system state is safe\n");
    print_safe_sequence(seq);
  } else {
    printf("Initial system state is unsafe\n");
    exit(1);
  }

  // Custom request via command line arguments: bankers <pid> <r0> <r1> <r2>
  if (argc == 5) {
    int pid = atoi(argv[1]);
    int req[R];
    req[0] = atoi(argv[2]);
    req[1] = atoi(argv[3]);
    req[2] = atoi(argv[4]);
    if (pid >= 0 && pid < P) {
      request_resources(pid, req);
    }
    exit(0);
  }

  // Scenario 1: Request that can be safely granted
  printf("\nScenario 1 (Safe Request):\n");
  int req1[R] = {1, 0, 2};
  request_resources(1, req1);

  // Scenario 2: Request that must be denied due to unsafe state
  printf("\nScenario 2 (Unsafe Request):\n");
  int req2[R] = {0, 2, 0};
  request_resources(0, req2);

  exit(0);
}
